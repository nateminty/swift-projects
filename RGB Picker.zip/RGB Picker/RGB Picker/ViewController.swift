//
//  ViewController.swift
//  RGB Picker
//
//  Created by Nathan Mintz on 4/29/22.
//

import UIKit
import Foundation


class ViewController: UIViewController {
    @IBOutlet weak var rSlider: UISlider!
    @IBOutlet weak var rLabel: UILabel!
    
    @IBOutlet weak var gSlider: UISlider!
    @IBOutlet weak var gLabel: UILabel!
    
    @IBOutlet weak var bSlider: UISlider!
    @IBOutlet weak var bLabel: UILabel!
    
    @IBOutlet weak var colorBox: UIView!
    
    @IBOutlet weak var whiteButton: UIButton!
    @IBOutlet weak var grayButton: UIButton!
    @IBOutlet weak var blackButton: UIButton!
    
    @IBOutlet weak var aLabel: UILabel!
    @IBOutlet weak var aSlider: UISlider!
    @IBOutlet weak var lockSwitch: UISwitch!
    @IBOutlet weak var titleLabel: UILabel!
    
    var locked: Bool = false;
    var r_g: Float!
    var r_b:Float!
    var b_g:Float!
    var biggest:String!
    
    var rVal: Float = 0.0;
    var gVal: Float = 0.0;
    var bVal: Float = 0.0;
    var alphaVal: Float = 0.0;
    
    var bgOn: Bool = false;
    
    func updateBox() {
//        print(CGFloat(floor(gVal)/255
//        ));
        //print(gVal);
        let color = UIColor(red: CGFloat(floor(rVal)/255), green: CGFloat(floor(gVal)/255), blue: CGFloat(floor(bVal)/255), alpha: CGFloat(alphaVal));

        titleLabel.textColor = color;
        
        colorBox.backgroundColor = color;
    }
    
    func updateSliders() {
        rSlider.value = rVal;
        rLabel.text = Int(rVal).description;
        
        gSlider.value = gVal;
        gLabel.text = Int(gVal).description;
        
        bSlider.value = bVal;
        bLabel.text = Int(bVal).description;
        
        rSlider.tintColor = UIColor(red: CGFloat(rVal/255), green: CGFloat(0), blue: CGFloat(0), alpha: 1);
        gSlider.tintColor = UIColor(red: CGFloat(0), green: CGFloat(gVal/255), blue: CGFloat(0), alpha: 1);
        bSlider.tintColor = UIColor(red: CGFloat(0), green: CGFloat(0), blue: CGFloat(bVal/255), alpha: 1);
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        aSlider.transform = CGAffineTransform(rotationAngle: CGFloat(-Double.pi/2));
        aSlider.value = 1.0;
        alphaVal = 1.0;
        aLabel.text = alphaVal.description;
        
        rSlider.thumbTintColor = .red;
        rSlider.tintColor = .red;
        
        gSlider.thumbTintColor = .green;
        gSlider.tintColor = .green;
        
        bSlider.thumbTintColor = .blue;
        bSlider.tintColor = .blue;
        
        rVal = 0.0;
        gVal = 0.0;
        bVal = 0.0;
        
        updateSliders();
        
        colorBox.layer.borderWidth = 5;
        colorBox.layer.borderColor = UIColor.lightGray.cgColor;
        colorBox.layer.cornerRadius = 5;
        
        updateBox();
    }
    
//    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
//        bgOn = !bgOn;
//        if bgOn {
//            view.backgroundColor = UIColor(red:CGFloat(rVal/255), green:CGFloat(gVal/255),blue:CGFloat(bVal/255),alpha:1);
//            colorBox.backgroundColor = .white;
//        }
//        else {
//            view.backgroundColor = .white;
//            colorBox.backgroundColor = UIColor(red:CGFloat(rVal/255), green:CGFloat(gVal/255),blue:CGFloat(bVal/255),alpha:1);
//        }
//    }
    @IBAction func aSliderChanged(_ sender: Any) {
        aLabel.text = String(format: "%.1f", aSlider.value);
        alphaVal = aSlider.value;
        
//        aSlider.tintColor = UIColor(red:CGFloat(aSlider.value), green:CGFloat(aSlider.value), blue:CGFloat(aSlider.value), alpha:1);
        aSlider.tintColor = .lightGray;
        updateBox();
    }
    
    @IBAction func redSliderChanged(_ sender: Any) {
        if locked {
            gSlider.value = rSlider.value/r_g
            ;
            gVal = gSlider.value;
            gLabel.text =
                Int(gSlider.value).description;
            bSlider.value = rSlider.value/r_b;
            bVal = bSlider.value;
            bLabel.text = Int(bSlider.value).description;
        }
        rVal = rSlider.value;
        
        rLabel.text = Int(rVal).description;
        rSlider.tintColor = UIColor(red: CGFloat(rVal/255), green: CGFloat(0.0), blue: CGFloat(0.0), alpha: 1);
        updateBox();
    }
    
    @IBAction func greenSliderChanged(_ sender: Any) {
        if locked {
            rSlider.value = gSlider.value * r_g;
            rVal = rSlider.value;
            rLabel.text = Int(rSlider.value).description;
            bSlider.value = gSlider.value*b_g;
            bVal = bSlider.value;
            bLabel.text = Int(bSlider.value).description;
            
        }
        gVal = gSlider.value;
        gLabel.text = Int(gVal).description;
        gSlider.tintColor = UIColor(red: CGFloat(0), green: CGFloat(gVal/255), blue: CGFloat(0), alpha: 1);
        //gSlider.tintColor = .green;
        updateBox();
    }
    
    @IBAction func blueSliderChanged(_ sender: Any) {
        if locked {
            rSlider.value = bSlider.value * r_b;
            rVal = rSlider.value;
            rLabel.text = Int(rSlider.value).description;
            gSlider.value = bSlider.value/b_g;
            gVal = gSlider.value;
            gLabel.text = Int(gSlider.value).description;
        }
        bVal = bSlider.value;
        bLabel.text = Int(bVal).description;
        bSlider.tintColor = UIColor(red: CGFloat(0), green: CGFloat(0), blue: CGFloat(bVal/255), alpha: 1);
        updateBox();
    }
    
    @IBAction func whitePress(_ sender: Any) {
        rVal = 255.0;
        gVal = 255.0;
        bVal = 255.0;
        
        updateSliders();
        updateBox();
    }
    
    @IBAction func grayPress(_ sender: Any) {
        rVal = 125.0;
        gVal = 125.0;
        bVal = 125.0;
        
        updateSliders();
        updateBox();
    }
    
    @IBAction func blackPress(_ sender: Any) {
        rVal = 0.0;
        gVal = 0.0;
        bVal = 0.0;
        
        updateSliders();
        updateBox();
    }
    
    @IBAction func lockChanged(_ sender: Any) {
        if lockSwitch.isOn {
            locked = true;
            
            r_g = rSlider.value/gSlider.value;
            r_b = rSlider.value/bSlider.value;
            b_g = bSlider.value/gSlider.value;
            
            if rSlider.value > gSlider.value {
                if rSlider.value > bSlider.value {
                    biggest = "R";
                }
                else {
                    biggest = "B";
                }
            }
            else {
                if gSlider.value > bSlider.value {
                    biggest = "G";
                }
                else {
                    biggest = "B";
                }
            }
            
        } else {
            locked = false;
        }
    }
}

