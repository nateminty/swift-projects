//
//  ViewController.swift
//  flappy-bird
//
//  Created by Nathan Mintz on 5/11/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var bird: UIImageView!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var topPipe1: UIImageView!
    @IBOutlet weak var bottomPipe1: UIImageView!
    @IBOutlet weak var bottomPipe2: UIImageView!
    @IBOutlet weak var topPipe2: UIImageView!
    @IBOutlet weak var ground: UIImageView!
    
    var timer: Timer!
    var time: Int = 0;
    var score: Int = 0;
    var scored1: Bool = false;
    var scored2: Bool = false;
    var playing: Bool = true;
    var lr: Bool = true;
    
    var gravity: CGFloat = 0.1;
    var dy: CGFloat = 0.0;
    var flapSpeed: CGFloat = -5;
    
    let WIDTH = UIScreen.main.bounds.width;
    let HEIGHT = UIScreen.main.bounds.height;
    
    override func viewDidLoad() {
        super.viewDidLoad()
        timeLabel.layer.zPosition = 1;
        topPipe1.center.x = WIDTH + topPipe1.bounds.width/2;
        bottomPipe1.center.x = WIDTH + bottomPipe1.bounds.width/2;
        topPipe2.center.x = WIDTH + 600;
        bottomPipe2.center.x = WIDTH + 600;
        timer = Timer.scheduledTimer(timeInterval: 0.01, target: self, selector: #selector(self.update), userInfo: nil, repeats: true)
        // -140 < x < -15
        let rand = Int.random(in: 15..<140) * -1;
        topPipe1.center.y = CGFloat(rand) + topPipe1.bounds.height/2;
        bottomPipe1.center.y = topPipe1.center.y + topPipe1.bounds.height/2 + 190 + bottomPipe1.bounds.height/2;
    }
    
    @objc func update() {
        if lr {
            ground.center.x += 2;
            lr = !lr;
        }
        else {
            ground.center.x -= 2;
            lr = !lr;
        }
        
        if bird.center.y + bird.bounds.height/2 >= ground.center.y - ground.bounds.height/2 {
            playing = false;
        }
        
        if bird.center.x + bird.bounds.width/2 >= bottomPipe1.center.x - bottomPipe1.bounds.width/2 && bird.center.x - bird.bounds.width/2 <= bottomPipe1.center.x + bottomPipe1.bounds.width/2 {
            if bird.center.y + bird.bounds.height/2 >= bottomPipe1.center.y - bottomPipe1.bounds.height/2 {
                //print("here");
                playing = false;
            }
        }
        if bird.center.x + bird.bounds.width/2 >= topPipe1.center.x - topPipe1.bounds.width/2 && bird.center.x - bird.bounds.width/2 <= topPipe1.center.x - topPipe1.bounds.width/2 {
            if bird.center.y - bird.bounds.height/2 < topPipe1.center.y + topPipe1.bounds.height/2 {
                //print("here");
                playing = false;
            }
        }
        
        if bird.center.x + bird.bounds.width/2 >= bottomPipe2.center.x - bottomPipe2.bounds.width/2 && bird.center.x - bird.bounds.width/2 <= bottomPipe2.center.x + bottomPipe2.bounds.width/2 {
            if bird.center.y + bird.bounds.height/2 >= bottomPipe2.center.y - bottomPipe2.bounds.height/2 {
                //print("here");
                playing = false;
            }
        }
        if bird.center.x + bird.bounds.width/2 >= topPipe2.center.x - topPipe2.bounds.width/2 && bird.center.x - bird.bounds.width/2 <= topPipe2.center.x - topPipe2.bounds.width/2 {
            if bird.center.y - bird.bounds.height/2 < topPipe2.center.y + topPipe2.bounds.height/2 {
                //print("here");
                playing = false;
            }
        }
        
        if playing {
        time += 1;
        //timeLabel.text = time.description;
        dy += gravity;
        bird.center.y += dy;
        if bird.center.y + bird.bounds.height/2 > HEIGHT {
            bird.center.y = HEIGHT - bird.bounds.height/2;
            dy = 0;
        }
        
        let headingAngle: CGFloat = dy*0.125;
        UIView.animate(withDuration: 0.1, animations: {
            self.bird.transform = CGAffineTransform(rotationAngle: headingAngle);
        });
        
        topPipe1.center.x += -1;
        bottomPipe1.center.x += -1;
        topPipe2.center.x += -1;
        bottomPipe2.center.x += -1;
        if topPipe1.center.x + topPipe1.bounds.width/2 < 0 {
            topPipe1.center.x = WIDTH + topPipe1.bounds.width/2;
            let rand = Int.random(in: 15..<140) * -1;
            topPipe1.center.y = CGFloat(rand) + topPipe1.bounds.height/2;
            bottomPipe1.center.y = topPipe1.center.y + topPipe1.bounds.height/2 + 190 + bottomPipe1.bounds.height/2;
            scored1 = false;
        }
        if bottomPipe1.center.x + bottomPipe1.bounds.width/2 < 0 {
            bottomPipe1.center.x = WIDTH + bottomPipe1.bounds.width/2;
        }
            
            if topPipe2.center.x + topPipe2.bounds.width/2 < 0 {
                topPipe2.center.x = WIDTH + topPipe2.bounds.width/2;
                let rand = Int.random(in: 15..<140) * -1;
                topPipe2.center.y = CGFloat(rand) + topPipe2.bounds.height/2;
                bottomPipe2.center.y = topPipe2.center.y + topPipe2.bounds.height/2 + 190 + bottomPipe2.bounds.height/2;
                scored2 = false;
            }
            if bottomPipe2.center.x + bottomPipe2.bounds.width/2 < 0 {
                bottomPipe2.center.x = WIDTH + bottomPipe2.bounds.width/2;
            }
        
        if !scored1
        {
            if bird.center.x - bird.bounds.width/2 >= topPipe1.center.x + topPipe1.bounds.width/2 {
//                if bird.center.y + bird.bounds.height/2 < bottomPipe1.center.y - bottomPipe1.bounds.height/2 && bird.center.y - bird.bounds.height/2 > topPipe1.center.y + topPipe1.bounds.height/2 {
                    score += 1;
                    scored1 = true;
                //}
            }
        }
            
            if !scored2
            {
                if bird.center.x - bird.bounds.width/2 >= topPipe2.center.x + topPipe2.bounds.width/2 {
    //                if bird.center.y + bird.bounds.height/2 < bottomPipe1.center.y - bottomPipe1.bounds.height/2 && bird.center.y - bird.bounds.height/2 > topPipe1.center.y + topPipe1.bounds.height/2 {
                        score += 1;
                        scored2 = true;
                    //}
                }
            }
        timeLabel.text = score.description;
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        dy = flapSpeed;
        if !playing {
            bird.center.y = 283;
            score = 0;
            topPipe1.center.x = WIDTH + topPipe1.bounds.width/2;
            bottomPipe1.center.x = WIDTH + bottomPipe1.bounds.width/2;
            topPipe2.center.x = WIDTH + topPipe2.bounds.width*3;
            bottomPipe2.center.x = WIDTH + bottomPipe2.bounds.width*3;
            // -140 < x < -15
            let rand = Int.random(in: 15..<140) * -1;
            topPipe1.center.y = CGFloat(rand) + topPipe1.bounds.height/2;
            bottomPipe1.center.y = topPipe1.center.y + topPipe1.bounds.height/2 + 190 + bottomPipe1.bounds.height/2;
            playing = true;
        }
    }
    }
